"""Independent source/data checks for EU-Core-1 4f237b0.

Does not compile or execute Rust, and does not reproduce neural trajectories.
The stationary reference uses NumPy integer fields and explicit scalar accounts.
"""
from pathlib import Path
import collections, copy, csv, hashlib, json, math, re, sqlite3, struct, subprocess, sys
import numpy as np

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'e-uni'
def read_csv(name):
    with (REPO / 'docs/d1' / name).open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))
def integer(row, name):
    return int(row[name])
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def parse_rules():
    source = (REPO/'crates/universe_types/src/rules.rs').read_text(encoding='utf-8')
    block = source.split('pub fn eu_core_1() -> Self {',1)[1].split('pub fn validate(',1)[0]
    constants = {'INPUTS':64, 'HIDDEN':32, 'LOGICAL_CHANNELS':12, 'POLICY_LOGITS':16,
                 'RuleProfile::EuCore1':1, 'Boundary::Closed':1,
                 'LearningKind::IndependentReadoutActorCriticV1':1,
                 'ReproductionKind::AsexualEmbryoV1':1,
                 'MutationKind::BoundedParameterMutationV1':1,
                 'std::f64::consts::PI':math.pi}
    vals, group = {}, None
    for line in block.splitlines():
        m = re.fullmatch(r'\s*(\w+): \w+Rules \{',line)
        if m:
            group=m[1]; continue
        if line.strip()== '},':
            group=None; continue
        m = re.fullmatch(r'\s*(\w+): (.*),',line)
        if not m: continue
        key,expr=m.groups()
        path=f'{group}.{key}' if group else key
        expr=re.sub(r' as u32$', '', expr)
        if expr in constants: value=constants[expr]
        elif expr in ('true','false'): value=expr=='true'
        elif expr.startswith('"'):
            value=expr.split('"')[1]
        elif re.fullmatch(r'[0-9_]+(?: \* [0-9_]+)*',expr):
            value=math.prod(int(x.replace('_','')) for x in expr.split('*'))
        elif re.fullmatch(r'[0-9.e+\-]+',expr): value=float(expr)
        else: raise ValueError(('unhandled literal',path,expr))
        vals[path]=value
    encoding=source.split('pub fn encode_canonical(&self)',1)[1].split('Ok(w.into_inner())',1)[0]
    def encode(values):
        out=bytearray(b'EUR1'+struct.pack('<I',1))
        formats={'u8':'B','u32':'I','u64':'Q','i32':'i','bool':'B','f64_canonical':'d'}
        for line in encoding.splitlines():
            m=re.search(r'w\.(\w+)\(self\.(.*?)\)\??;',line)
            if not m: continue
            typ,expr=m.groups()
            if expr.endswith('.len() as u64'):
                value=len(values[expr[:-13]].encode())
            elif expr.endswith('.as_bytes()'):
                value=values[expr[:-11]].encode()
            else:
                expr=expr.replace('.code()','').replace(' as u8','')
                value=values[expr]
            if typ=='raw': out.extend(value)
            else: out.extend(struct.pack('<'+formats[typ],value))
        return bytes(out)
    return vals, encode

def stationary(case, max_ticks=20000):
    """Independent integer-account reference, no Rust/brain/geometry execution."""
    n=np.full((16,16),500000,dtype=np.int64)
    q=np.zeros((16,16),dtype=np.int64)
    q[7:10,3:6]=200000
    rem=np.zeros_like(q)
    is_dark=case=='C1'
    initial_q_before=int(q.sum())
    if is_dark: q[:]=0
    x,y=(4,8) if case=='C0' else (8,8)
    E,C,N,B,debt=5000000,500000,100000,1000000,0
    totals=collections.Counter()
    def diffuse(a,div):
        delta=np.zeros_like(a)
        dx=a[:,:-1]-a[:,1:]
        fx=np.sign(dx)*(np.abs(dx)//div)
        delta[:,:-1]-=fx; delta[:,1:]+=fx
        dy=a[:-1,:]-a[1:,:]
        fy=np.sign(dy)*(np.abs(dy)//div)
        delta[:-1,:]-=fy; delta[1:,:]+=fy
        return a+delta
    samples=[]
    for t in range(max_ticks):
        pay=min(E,2192); E-=pay; debt+=2192-pay; totals['maintenance_paid']+=pay
        repay=min(E,2000,debt) if pay==2192 else 0
        E-=repay; debt-=repay; totals['debt_repaid']+=repay
        if t%5==0 and pay==2192 and E>=809:
            E-=809; totals['cognition_paid']+=809; totals['decision_count']+=1
        if not is_dark: q[7:10,3:6]+=20000
        n=diffuse(n,64); q=diffuse(q,16)
        accum=q+rem; loss=accum//16; rem=accum%16; q-=loss
        up=min(2000,int(n[y,x]),250000-N); n[y,x]-=up; N+=up
        ph=min(2000,N,4000000-C,int(q[y,x])//20)
        N-=ph; q[y,x]-=20*ph; C+=ph; totals['photo_extent']+=ph
        extent=min(1000,(6000000-E)//8,C) if E<6000000 else 0
        C-=extent; E+=8*extent; n[y,x]+=extent; totals['catabolic_E']+=8*extent
        P=E+8*C
        dead=debt>=200000
        if (t+1)%100==0 or dead:
            samples.append({'tick':t+1,'E':E,'C':C,'N':N,'P':P,'debt':debt,
                            'photo_extent':totals['photo_extent']})
        if dead: break
    return {'executed_ticks':t+1,'death_tick':t if dead else None,
            'P_before_death_or_end':P,'E':E,'C':C,'debt':debt,
            'initial_q_before_extinguish':initial_q_before,
            'initial_q_executed':0 if is_dark else initial_q_before,
            'totals':dict(totals),'samples':samples}

def main():
    runs,windows,decisions=(read_csv(x) for x in ('runs.csv','windows.csv','decisions.csv'))
    out={'method':'Independent Python source/data calculations; Rust not executed',
         'python':sys.version.split()[0], 'numpy':np.__version__, 'sqlite':sqlite3.sqlite_version,
         'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
         'input_hashes':{p:sha(REPO/p) for p in ['docs/d1/runs.csv','docs/d1/windows.csv','docs/d1/decisions.csv','crates/universe_core/src/brain.rs','crates/universe_core/src/world.rs','crates/universe_core/src/sense.rs']},
         'counts':{'runs':len(runs),'windows':len(windows),'decisions':len(decisions)},
         'manifest_commit':json.loads((REPO/'docs/d1/manifest.json').read_text(encoding='utf-8'))['commit']}
    assert out['source_commit']=='4f237b0e4adddf3df42ebf782b4367e9ac2ef3ab', 'This checker is pinned to 4f237b0'
    assert (len(runs),len(windows),len(decisions))==(45,3487,9)
    out['reported_run_errors']=[{'group':r['group'],'seed':r['seed'],'error':r['error']} for r in runs if r['error']]
    assert not out['reported_run_errors']
    c5=[r for r in runs if r['group'].startswith('C5')]
    byseed=collections.defaultdict(dict)
    for r in c5: byseed[int(r['seed'])][r['group']]=r
    assert sorted(byseed)==list(range(101,121))
    assert all(set(p)=={'C5-learn','C5-freeze'} for p in byseed.values())
    diffs=[int(byseed[s]['C5-learn']['catabolic_E_after'])-int(byseed[s]['C5-freeze']['catabolic_E_after']) for s in sorted(byseed)]
    mask=(1<<64)-1
    rngstate=20260910|1
    def next_u64():
        nonlocal rngstate
        rngstate=(rngstate+0x9E3779B97F4A7C15)&mask
        z=rngstate; z=((z^(z>>30))*0xBF58476D1CE4E5B9)&mask
        z=((z^(z>>27))*0x94D049BB133111EB)&mask
        return z^(z>>31)
    means=sorted(sum(diffs[next_u64()%20] for _ in range(20))/20 for _ in range(2000))
    out['c5_bootstrap']={'mean':sum(diffs)/20,'lo':means[50],'hi':means[1950],
                         'paired_diffs_muE':diffs,'stat_seed':20260910,'resamples':2000}
    out['c5_groups']={g:{'alive_at_switch':sum(r['alive_at_switch']=='1' for r in c5 if r['group']==g),
                        'alive_at_end':sum(r['alive_at_end']=='1' for r in c5 if r['group']==g),
                        'errors':[r['seed'] for r in c5 if r['group']==g and r['error']]}
                      for g in ['C5-learn','C5-freeze']}
    residuals=[]
    for r in runs:
        income=8*(int(r['photo_extent_before'])+int(r['photo_extent_after'])+int(r['organic_intake_before'])+int(r['organic_intake_after']))
        costs=sum(int(r[k]) for k in ['maintenance_paid','cognition_paid','movement_paid','turn_paid','debt_repaid'])
        residual=int(r['P_before_death_or_end'])-int(r['P_initial'])-income+costs
        residuals.append(residual)
        assert int(r['cognition_paid'])==int(r['decision_count'])*809
        if r['death_tick']: assert int(r['executed_ticks'])==int(r['death_tick'])+1
        if r['group']=='C5-freeze': assert int(r['learning_update_count'])==0
    out['run_P_balance']={'checked':len(residuals),'max_abs':max(map(abs,residuals)),
                         'nonzero':[i for i,x in enumerate(residuals) if x]}
    out['window_P_definition']={'checked':len(windows),'mismatches':sum(int(r['P'])!=int(r['E'])+8*int(r['C']) for r in windows)}
    assert not out['run_P_balance']['nonzero']
    assert out['window_P_definition']['mismatches']==0
    out['decision_sample']={'count':len(decisions),'first_tick':int(decisions[0]['tick']),
                           'last_tick':int(decisions[-1]['tick']),
                           'largest_sampled_A_minus_A0':max(float(r['A_minus_A0']) for r in decisions)}
    vals,encode=parse_rules()
    basehash=hashlib.sha256(encode(vals)).hexdigest()
    assert basehash=='6e27f665f00d508e8a49b0a9fb6409163fa4c7970ec3d58755f13b90ae180a9b',basehash
    lab=copy.deepcopy(vals)
    lab.update({'world.width_lu':16.,'world.height_lu':16.,'world.grid_width':16,'world.grid_height':16,
                'lighting.left_x0':3,'lighting.left_x1':5,'lighting.right_x0':3,'lighting.right_x1':5,
                'lighting.y0':7,'lighting.y1':9,'init.initial_count':1})
    right=dict(lab,**{'lighting.left_x0':10,'lighting.left_x1':12,'lighting.right_x0':10,'lighting.right_x1':12})
    out['rules_hashes']={'base_128':basehash,'lab_left_16':hashlib.sha256(encode(lab)).hexdigest(),
                        'lab_right_16':hashlib.sha256(encode(right)).hexdigest(),
                        'canonical_bytes':len(encode(vals))}
    campaign=b'EUD1'+struct.pack('<IQQQQ',1,16,16,10000,20000)+b'P=E+8C'+b'C0-C5'+struct.pack('<Q',20)
    campaign+=b''.join(struct.pack('<Q',s) for s in range(101,121))
    out['campaign_experiment_hash']=hashlib.sha256(campaign).hexdigest()
    assert out['campaign_experiment_hash']=='ed239810b5f6a28a9c00d100329c99527e9dc9c61b63739682db731cdf191e63'
    out['stationary_reference']={}
    for case in ['C0','C1','C2']:
        result=stationary(case)
        r=next(r for r in runs if r['group']==case)
        checks={'executed_ticks':result['executed_ticks']==int(r['executed_ticks']),
                'death_tick':result['death_tick']==(int(r['death_tick']) if r['death_tick'] else None),
                'P_final':result['P_before_death_or_end']==int(r['P_before_death_or_end']),
                'photo_total':result['totals']['photo_extent']==int(r['photo_extent_before'])+int(r['photo_extent_after'])}
        indexed={x['tick']:x for x in result['samples']}
        wc=0; wm=[]
        for wr in [x for x in windows if x['group']==case and x['living']=='1']:
            wc+=1; calc=indexed[int(wr['tick'])]
            for key in ['E','C','N','P','photo_extent']:
                if calc[key]!=int(wr[key]): wm.append((wr['tick'],key,calc[key],wr[key]))
        result.pop('samples')
        result['summary_matches']=checks
        result['living_window_checks']=wc
        result['window_mismatches']=wm
        out['stationary_reference'][case]=result
        assert all(checks.values()) and not wm, (case,checks,wm)
    # Source-order trace: sense(last_feedback), then rotate completed feedback.
    last=None; completed=None; trace=[]
    for tick in [0,5,10,15]:
        read=last
        last=completed
        trace.append({'decision_tick':tick,'neural_feedback_interval':read,'C4_feedback_interval':last})
        completed=[tick,tick+5]
    out['feedback_source_order_model']=trace
    out['motion_feedback_source_formula']={'full_turn_observation':1/math.pi,
                                         'expected_full_turn_normalized':1.0,
                                         'wall_push_observation':1.0,
                                         'expected_wall_push_actual_motion':0.0}
    out['fault_test_fixture']={'tick':0,'freeze_learning':True,'disable_reproduction':True,
                               'brain_readout_update_exercised':False,'embryo_or_birth_exercised':False}
    # Exercise the archive's autocommit INSERT pattern with SQLite, not Rust.
    db=sqlite3.connect(':memory:',isolation_level=None)
    db.execute('CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT,tick INTEGER NOT NULL,kind INTEGER NOT NULL,a INTEGER NOT NULL,b INTEGER NOT NULL,amount INTEGER NOT NULL)')
    db.execute("CREATE TRIGGER fail_second BEFORE INSERT ON events WHEN NEW.a=2 BEGIN SELECT RAISE(ABORT,'injected'); END")
    insert='INSERT INTO events(tick,kind,a,b,amount) VALUES (?,?,?,?,?)'
    db.execute(insert,(10,1,1,0,20))
    try: db.execute(insert,(10,1,2,0,20))
    except sqlite3.DatabaseError: pass
    partial=db.execute('SELECT COUNT(*) FROM events').fetchone()[0]
    db.execute('DROP TRIGGER fail_second')
    db.execute(insert,(10,1,1,0,20))
    db.execute(insert,(10,1,2,0,20))
    out['sqlite_archive_pattern']={'rows_after_second_insert_failure':partial,
                                  'rows_after_retry_same_event_list':db.execute('SELECT COUNT(*) FROM events').fetchone()[0],
                                  'expected_idempotent_complete_rows':2}
    assert partial==1 and out['sqlite_archive_pattern']['rows_after_retry_same_event_list']==3
    db.close()
    (ROOT/'audit_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
